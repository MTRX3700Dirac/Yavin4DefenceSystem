The Zip files for Code-  main section demonstrated the serial interface and tracking
Code - Local interface demonstrated the local UI
Code - Without Watchdog was the code we should have presented =(